<!DOCTYPE html>
<head>
    <TITle>LISTA DE PRODUTOS DE SALÃO</TITle>

</head>
<body>
    <h1>Produtos</h1>
<ul>
<?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
<?php echo e($produto->id); ?>- NM<?php echo e($produto->nome_produto); ?>- R$ <?php echo e(number_format($produto->preco,2 ,',','.')); ?>

</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</body>
</html>
<?php /**PATH /home/bach/Documentos/GitHub/Exercicios-BackEnd/projeto/resources/views/produtos/index.blade.php ENDPATH**/ ?>