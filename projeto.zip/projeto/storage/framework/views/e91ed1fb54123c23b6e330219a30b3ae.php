<!DOCTYPE html>
<head>
    <TITle>LISTA DE USUARIOS</TITle>

</head>
<body>
    <h1>Usuarios</h1>
<ul>
<?php $__currentLoopData = $Usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
    <?php echo e($usuario->nome); ?>- @ <?php echo e(($usuario->email)); ?>

</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</body>
</html>
<?php /**PATH /home/bach/Documentos/GitHub/Exercicios-BackEnd/projeto/resources/views/usuarios/index.blade.php ENDPATH**/ ?>