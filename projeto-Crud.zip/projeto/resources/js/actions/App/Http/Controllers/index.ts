import Auth from './Auth'
import ProdutoController from './ProdutoController'
import UsuarioController from './UsuarioController'
import Settings from './Settings'

const Controllers = {
    Auth: Object.assign(Auth, Auth),
    ProdutoController: Object.assign(ProdutoController, ProdutoController),
    UsuarioController: Object.assign(UsuarioController, UsuarioController),
    Settings: Object.assign(Settings, Settings),
}

export default Controllers